package com.example.demo;

import java.util.concurrent.Callable;

public class DeviceCallable implements Callable<String> {
    private Device device;

    public DeviceCallable(Device device){
        this.device = device;
    }

    @Override
    public String call() throws Exception {
        return  RemoteService.call(device);
    }
}
