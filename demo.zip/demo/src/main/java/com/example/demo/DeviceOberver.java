package com.example.demo;

import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.*;

public class DeviceOberver implements Observer {
    private ExecutorService executorService = new ThreadPoolExecutor(50, 80, 10*60, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(1000));
    private static DeviceOberver instance = new DeviceOberver();

    private DeviceOberver(){

    }

    public static DeviceOberver getInstance(){
        return instance;
    }

    public void process(Device device){
        System.out.println("start processing");
        try {
            FutureTask<String> futureTask = new FutureTask<String>(new DeviceCallable(device));
            executorService.execute(futureTask);
            futureTask.get(5l, TimeUnit.SECONDS);
            System.out.println("success for device "+ device.getId() );
        }catch (InterruptedException | ExecutionException e) {
            System.out.println("disturb for device "+ device.getId() );
        }catch (TimeoutException e){
            System.out.println("timeout for device "+ device.getId() );
        }
    }

    @Override
    public void update(Observable o, Object arg) {
        Device device = (Device) arg;
        process(device);
    }

    public void destoryPool(){
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException ex) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
