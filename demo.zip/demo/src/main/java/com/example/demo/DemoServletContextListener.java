package com.example.demo;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class DemoServletContextListener  implements ServletContextListener {

    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        System.out.println("DemoServletContextListener contextDestroyed start");
        DeviceOberver.getInstance().destoryPool();
        System.out.println("DemoServletContextListener contextDestroyed start");
    }

    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        System.out.println("DemoServletContextListener contextInitialized start");
        DeviceOberver deviceOberver = DeviceOberver.getInstance();
        DeviceOberable deviceOberable = DeviceOberable.getInstance();
        deviceOberable.addObserver(deviceOberver);
        System.out.println("DemoServletContextListener contextInitialized end");
    }

}
