package com.example.demo;

import java.util.Random;

public class RemoteService {
    private static Random random = new Random();
    public static String call(Device device){
        try {
            int val = random.nextInt(8);
            System.out.println("device " + device.getId() + " spend " + val + " seconds");
            Thread.sleep(val * 1000);
            return "success";
        }catch (Exception e){
            System.out.println("exception for remote service call");
            return "fail";
        }
    }
}
