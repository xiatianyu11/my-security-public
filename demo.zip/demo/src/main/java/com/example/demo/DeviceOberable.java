package com.example.demo;

import java.util.Observable;

public class DeviceOberable extends Observable {

    private static DeviceOberable instance = new DeviceOberable();

    private DeviceOberable(){

    }

    public static DeviceOberable getInstance(){
        return instance;
    }

    public void addDevice(Device device) {
        this.setChanged();
        this.notifyObservers(device);
    }
}